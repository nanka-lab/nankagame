"ここでゲームのプレイヤーからのイベント処理について記述します"
from . import classes

def player_keyevents():
    pass