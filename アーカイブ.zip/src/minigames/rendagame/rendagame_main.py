import pygame as pg
from pygame.locals import *
from . import classes as cl
from . import consts as c
from . import setup

def main():
    game = cl.Control()
    state_dict = {c.START: cl.Start(),
                  c.PLAY: cl.Play(),
                  c.COUNT_DOWN: cl.Count_down(),
                  c.RESULT: cl.Result()}
    game.setup_status(state_dict, c.START)
    result = game.main()
    return result