from src.minigames.rendagame import rendagame_main

rendagame_main.main()