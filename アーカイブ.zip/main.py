import pygame as pg
from src.nankagame import main #絶対インポート

#実行
if __name__ == "__main__":
    main() #メイン関数の実行
    pg.quit() #pygameが使用しているリソースの解放
    
