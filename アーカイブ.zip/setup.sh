#ターミナルで以下のコマンドを入力してください
#$chmod +x setup.sh
#$./setup.sh

#必要なパッケージのインストール

echo "requirements.txtに書かれてあるパッケージ類をインストールします"
pip install -r requirements.txt

echo "インストール完了"
